# Movie Trailer

1. Unzip the zip file, then double click fresh_tomatoes.html to open the webpage.
2. Click on any movie to watch the trailer
3. Alternatively, you can open movie.py, run it, and the same webpage will be opened.